# RS Chai & Chilli Cafe Android App

Android wrapper app for the cafe's existing HTML ordering page.

## GitHub
Upload the contents of this folder to your GitHub repository (keep the folder structure).

Then open **Actions** and run **Build Android APK**. After the workflow finishes:
**Actions → Build Android APK → Artifacts → RS-Chai-Chilli-Cafe-debug**.

The app uses the cafe WhatsApp number **+91 7366830143**.

## Important
This is Version 1. It wraps the current HTML ordering page in an Android app. It is not yet a multi-restaurant/Zomato-scale backend.
